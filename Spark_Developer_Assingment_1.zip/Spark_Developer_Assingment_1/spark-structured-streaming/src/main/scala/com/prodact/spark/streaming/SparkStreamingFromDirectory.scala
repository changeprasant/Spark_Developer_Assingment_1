package com.prodact.spark.streaming

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.types.{ IntegerType, StringType, StructField, StructType }
import org.apache.spark.sql.streaming.OutputMode
import org.apache.spark.sql.Row
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.TimestampType

object SparkStreamingFromDirectory {

  def main(args: Array[String]): Unit = {

    val spark: SparkSession = SparkSession.builder()
      .master("local[3]")
      .appName("SparkByExample")
      .getOrCreate()

    spark.sparkContext.setLogLevel("ERROR")
    import spark.implicits._

    val schema = StructType(
      List(
        StructField("message", StringType, true)))

    var df = spark.readStream
      .schema(schema)
      .json("./src/main/resources/input")

    df.printSchema()


    df = df.filter(col("message").contains("omwssu"))
    df = df.withColumn("timestamp", split(col("message"), "         ").getItem(1))
    df = df.withColumn("timestamp", concat(trim(split(col("timestamp"), "        ").getItem(0)), lit(" "), trim(split(col("timestamp"), "        ").getItem(1))))
    df = df.withColumn("timestamp", date_format($"timestamp", "yyyy-MM-dd'T'HH:mm:ss'Z'"))
//    df = df.withColumn("timestamp", date_format($"timestamp", "yyyy-MM-dd'T'HH:mm:ss'Z'").cast(TimestampType))
    
    
    
    df = df.withColumn("message", split(col("message"), "GET").getItem(1))
    df = df.withColumn("message", split(trim(col("message")), "1.1").getItem(0))

    df = df.withColumn("fqdn", concat(split(trim(col("message")), "/").getItem(0), lit("//"), split(trim(col("message")), "/").getItem(2), lit("/"), split(trim(col("message")), "/").getItem(3)))
    df = df.withColumn("cpe_id", split(trim(col("message")), "/").getItem(4))
    df = df.withColumn("action", split(trim(col("message")), "/").getItem(5))
    df = df.withColumn("error_code", concat(split(trim(col("message")), "/").getItem(6), lit("."), split(trim(col("message")), "/").getItem(7)))
    import org.apache.spark.sql.types._
    df = df.withColumn("error_code", df("error_code").cast(DoubleType))

    df.printSchema()
    
//    df.writeStream
//      .format("console")
//      .outputMode(OutputMode.Append)
//      .option("truncate", false)
////      .option("newRows", 30)
//      .start()
//      .awaitTermination()
      
      df.writeStream
      .format("json")
      .option("path", "E:/workspace/eclipse-scala/spark-structured-streaming/output")
      .option("checkpointLocation", "E:/workspace/checkpoint")
      .outputMode("append")
      .start().awaitTermination()
  }
}
